﻿using StudentMvcApp.DTOs;
using Microsoft.EntityFrameworkCore;
using StudentMvcApp.Models;

namespace StudentMvcApp
{
    public class StudentService
    {
        private readonly StudentDbContext _context;

        public StudentService(StudentDbContext context)
        {
            _context = context;
        }

        // Get all students
        public List<StudentDto> GetAll()
        {
            return _context.Students
                .Select(s => new StudentDto
                {
                    ID = s.Id,
                    Name = s.Name,
                    Age = s.Age,
                    Course = s.Course
                })
                .ToList();
        }

        public StudentDto? GetById(int id)
        {
            var student = _context.Students.Find(id);
            if (student == null) return null;

            return new StudentDto
            {
                ID = student.Id,
                Name = student.Name,
                Age = student.Age,
                Course = student.Course
            };
        }

        public void Add(StudentDto dto)
        {
            var student = new Student
            {
                Name = dto.Name,
                Age = dto.Age,
                Course = dto.Course
            };
            _context.Students.Add(student);
            _context.SaveChanges();
        }

        public void Update(StudentDto dto)
        {
            var student = _context.Students.Find(dto.ID);
            if (student == null) return;

            student.Name = dto.Name;
            student.Age = dto.Age;
            student.Course = dto.Course;

            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var student = _context.Students.Find(id);
            if (student == null) return;

            _context.Students.Remove(student);
            _context.SaveChanges();
        }
    }
}
