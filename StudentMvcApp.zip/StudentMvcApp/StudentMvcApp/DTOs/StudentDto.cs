﻿namespace StudentMvcApp.DTOs
{
    public class StudentDto
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Course { get; set; }
    }
}
